package com.civictrack.thecivictrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThecivictrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
